from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel,
    QPushButton, QLineEdit
)
from PyQt5.QtCore import Qt
import os
os.system("cls")

app = QApplication([])

oyna = QWidget()
oyna.setWindowTitle("Kalkulyator")
oyna.setGeometry(500, 150, 400, 500)

line1 = QLineEdit(oyna)
line1.setGeometry(25, 20, 355, 50)
line1.setStyleSheet("""
                    font-size: 28px;
                   background-color: white;
                   border: 2px solid black;
""")
line1.setPlaceholderText("Son 1ni kiriting...")

# Ikkinchi LineEdit
line2 = QLineEdit(oyna)
line2.setGeometry(25, 80, 355, 50)
line2.setStyleSheet("""
                    font-size: 28px;
                   background-color: white;
                   border: 2px solid black;
""")
line2.setPlaceholderText("Son 2ni kiriting...")

btn1 = QPushButton(oyna)
btn1.setText("+")
btn1.setStyleSheet("""
    font-size: 28px;
    background-color: white;
    border: 2px solid black;
""")
btn1.setGeometry(25, 150, 80, 45)

btn2 = QPushButton(oyna)
btn2.setText("-")
btn2.setStyleSheet("""
    font-size: 28px;
    background-color: white;
    border: 2px solid black;
""")
btn2.setGeometry(120, 150, 80, 45)

btn3 = QPushButton(oyna)
btn3.setText("*")
btn3.setStyleSheet("""
    font-size: 28px;
    background-color: white;
    border: 2px solid black;
""")
btn3.setGeometry(215, 150, 80, 45)

btn4 = QPushButton(oyna)
btn4.setText("/")
btn4.setStyleSheet("""
    font-size: 28px;
    background-color: white;
    border: 2px solid black;
""")
btn4.setGeometry(310, 150, 80, 45)

text1 = QLabel(oyna)
text1.setText("Natija:")
text1.setGeometry(25, 230, 355, 100) 
text1.setWordWrap(True) 
text1.setStyleSheet("""
        font-size: 28px;
        border: 2px solid black;
        background-color: #f0f0f0;
""")
text1.setAlignment(Qt.AlignCenter)

def hisobla(ishora):
    try:
        son1 = float(line1.text())
        son2 = float(line2.text())
        
        if ishora == "+":
            son = son1 + son2
        elif ishora == "-":
            son = son1 - son2
        elif ishora == "*":
            son = son1 * son2
        elif ishora == "/":
            if son2 == 0:
                text1.setText("Nolga bo'lish mumkin emas!")
                return
            son = son1 / son2
            
        if son.is_integer():
            son = int(son)
            
        text1.setText(f"Natija: {son}")
    except ValueError:
        text1.setText("Xatolik: Son kiriting!")

btn1.clicked.connect(lambda: hisobla("+"))
btn2.clicked.connect(lambda: hisobla("-"))
btn3.clicked.connect(lambda: hisobla("*"))
btn4.clicked.connect(lambda: hisobla("/"))

oyna.show()
app.exec_()