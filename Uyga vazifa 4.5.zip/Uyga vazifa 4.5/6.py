from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel,
    QPushButton, QLineEdit
)
from PyQt5.QtCore import Qt
import os
os.system("cls")
app = QApplication([])

oyna = QWidget()
oyna.setWindowTitle("Hisoblagich")
oyna.setGeometry(500, 150, 400, 400)

def qoshish():
    a = int(text1.text())
    text1.setText(str(a +1))
def ayirish():
    b = int(text1.text())
    text1.setText(str(b -1))


text1 = QLabel(oyna)
text1.setText("0")
text1.setGeometry(25, 25, 355, 100)
text1.setStyleSheet("""
    font-size: 26px;
    font-weight: bold;
    border: 2px solid black;
    background-color: white;
""")

btn1 = QPushButton(oyna)
btn1.setText("+")
btn1.setStyleSheet("""
    font-size: 28px;
    background-color: white;
    border: 2px solid black;
""")
btn1.setGeometry(25, 150, 80, 45)
btn1.clicked.connect(qoshish)

btn2 = QPushButton(oyna)
btn2.setText("-")
btn2.setStyleSheet("""
    font-size: 28px;
    background-color: white;
    border: 2px solid black;
""")
btn2.setGeometry(120, 150, 80, 45)
btn2.clicked.connect(ayirish)

oyna.show()
app.exec_()
