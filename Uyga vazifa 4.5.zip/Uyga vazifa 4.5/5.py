from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel,
    QPushButton, QLineEdit
)
from PyQt5.QtCore import Qt
import os
os.system("cls")
app = QApplication([])

oyna = QWidget()
oyna.setWindowTitle("Parol")
oyna.setGeometry(500, 150, 400, 400)

line1 = QLineEdit(oyna)
line1.setGeometry(25, 20, 355, 50)
line1.setStyleSheet("""
                    font-size: 28px;
                   background-color: white;
                   border: 2px solid black;
""")
line1.setPlaceholderText("Parolni kiriting...")

def parol():
    parol = line1.text()
    if parol == "12345":
        text1.setText("Tog'ri parol!")
    else:
        text1.setText("Noto'g'ri parol!")
        
btn = QPushButton(oyna)
btn.setText("Tekshirish")
btn.setGeometry(50, 220, 300, 50)
btn.setStyleSheet("""
    font-size: 22px;
    font-weight: bold;
    border: 2px solid black;
""")
btn.clicked.connect(parol)

text1 = QLabel(oyna)
text1.setText(parol())
text1.setGeometry(25, 100, 355, 100)
text1.setStyleSheet("""
    font-size: 26px;
    font-weight: bold;
    border: 2px solid black;
    background-color: white;
""")

oyna.show()
app.exec_()
