from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel,
    QPushButton, QLineEdit
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
import random
import os
os.system("cls")

app = QApplication([])

oyna = QWidget()
oyna.setWindowTitle("info")
oyna.setGeometry(1400, 200, 405, 720)

def ism():
    text1.setText("Muhammadsodiq")
def familiya():
    text1.setText("Mansurov")
def sana():
    text1.setText("15.01.2010")

text1 = QLabel(oyna)
text1.setText("Ma'lumot...") # Boshlang'ich matn
text1.setAlignment(Qt.AlignCenter) # Matnni o'rtaga tekislash
text1.setStyleSheet("""
    font-size: 24px;
    border: 2px solid #333;
    background-color: #f0f0f0;
    border-radius: 5px;
""")
text1.setGeometry(50, 150, 305, 80)

btn1 = QPushButton(oyna)
btn1.setText("Ism")
btn1.setStyleSheet("""
    font-size: 28px;
    background-color: white;
    border: 2px solid black;
""")
btn1.setGeometry(25, 400, 80, 30)
btn1.clicked.connect(ism)

btn2 = QPushButton(oyna)
btn2.setText("Familiya")
btn2.setStyleSheet("""
    font-size: 28px;
    background-color: white;
    border: 2px solid black;
""")
btn2.setGeometry(125, 400, 120, 30)
btn2.clicked.connect(familiya)


btn3 = QPushButton(oyna)
btn3.setText("Sana")
btn3.setStyleSheet("""
    font-size: 28px;
    background-color: white;
    border: 2px solid black;    
""")
btn3.setGeometry(265, 400, 90, 30)
btn3.clicked.connect(sana)


oyna.show()
app.exec_()