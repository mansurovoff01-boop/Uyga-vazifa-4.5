from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel,
    QPushButton, QLineEdit
)
from PyQt5.QtGui import QFont
import random
import os
os.system("cls")

app = QApplication([])

oyna = QWidget()
oyna.setWindowTitle("Random son")
oyna.setGeometry(1400, 200, 405, 720)

def random_son():
    random1 = random.randint(1, 100)
    text1.setText(str(random1))

btn1 = QPushButton(oyna)
btn1.setText("Random")
btn1.setStyleSheet("""
    font-size: 28px;
    background-color: white;
    border: 2px solid black;
""")
btn1.setGeometry(125, 400, 155, 50)

btn1.clicked.connect(random_son)

text1 = QLabel(oyna)
text1.setText("0")
text1.setGeometry(150, 50, 80, 60)
text1.setStyleSheet("""
        font-size: 40px;
        border: 2px solid black;
""")

text1.move(200, 50)


oyna.show()
app.exec_()