from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel,
    QPushButton, QLineEdit
)
from PyQt5.QtCore import Qt
import os
import random
os.system("cls")

app = QApplication([])

oyna = QWidget()
oyna.setWindowTitle("Random rang")
oyna.setGeometry(500, 150, 400, 400)

text1 = QLabel(oyna)
text1.setText("Mening rangim o'zgaradi!")
text1.setGeometry(25, 50, 355, 100)
text1.setStyleSheet("""
    font-size: 26px;
    font-weight: bold;
    border: 2px solid black;
    background-color: white;
""")

def rangni_ozgartir():
    ranglar = ["red", "blue", "green", "yellow", "purple", "orange", "magenta"]
    tasodifiy_rang = random.choice(ranglar)
    
    text1.setStyleSheet(f"""
        font-size: 26px;
        font-weight: bold;
        border: 2px solid black;
        background-color: white;
        color: {tasodifiy_rang};
    """)

btn = QPushButton(oyna)
btn.setText("Rangni o'zgartirish")
btn.setGeometry(50, 220, 300, 50)
btn.setStyleSheet("""
    font-size: 22px;
    font-weight: bold;
    border: 2px solid black;
""")

btn.clicked.connect(rangni_ozgartir)

oyna.show()
app.exec_()